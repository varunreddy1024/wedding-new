import React from 'react';
import brideImage from './pranay.jpeg';
import groomImage from './pranay.jpeg';
import heartImage from './love-fill.png';

function AboutComponent() {
    return ( <
        div className = "page-about" >
        <
        div className = "div-photo" >
        <
        div className = "photo-main" >
        <
        div className = "photo-sub" >
        <
        img src = { brideImage }
        alt = "Bride" / >
        <
        /div> <
        div className = "photo-sub" >
        <
        img src = { groomImage }
        alt = "Groom" / >
        <
        /div> <
        /div> <
        div className = "hov-pho" >
        <
        div className = "photo-sub" >
        <
        img src = { heartImage }
        alt = "Heart" / >
        <
        /div> <
        /div> <
        /div> <
        div className = "about-main" >
        <
        div className = "about-sub text-right" >
        <
        p className = "text7 cred folav" > Bride < /p> <
        p className = "text5" >
        Lorem ipsum dolor, sit amet consectetur adipisicing elit.Deserunt rerum consectetur dolore!Vero, quaerat.Magni ?
        <
        /p> <
        /div> <
        div className = "about-sub" >
        <
        p className = "text7 cred folav" > Groom < /p> <
        p className = "text5" >
        Lorem ipsum dolor, sit amet consectetur adipisicing elit.Deserunt rerum consectetur dolore!Vero, quaerat.Magni ?
        <
        /p> <
        /div> <
        /div> <
        /div>
    );
}

export default AboutComponent;