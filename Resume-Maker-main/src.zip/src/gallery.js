import React from 'react';
import loveBirdImage from './love-bird.png';
import loveDualImage from './love-dual.png';
import pranayImage from './pranay.jpeg';

const FamilyComponent = () => {
    // Define the JavaScript function to handle the click event
    const changeRelation = (index) => {
        // Your logic for changing the relation based on the index goes here
        // For example:
        console.log(`Clicked on family member ${index}`);
    };

    return ( <
        div >
        <
        div className = "page-family" >
        <
        div className = "div-title" >
        <
        div className = "title-top-icon" >
        <
        img src = { loveBirdImage }
        alt = "" / >
        <
        /div> <
        div className = "title-text-div" >
        <
        p className = "font-title cblack" > Family < /p> <
        /div> <
        div className = "title-bottom-icon" >
        <
        img src = { loveDualImage }
        alt = "" / >
        <
        /div> <
        /div>

        <
        div className = "car-man" > { /* Family members */ } { /* Use map to generate family member cards */ } {
            [0, 1].map((index) => ( <
                div key = { index }
                className = "cir-div-card car-man-BG"
                onClick = {
                    () => changeRelation(index) } >
                <
                div className = "cir-card-top" >
                <
                img src = { pranayImage }
                alt = "" / >
                <
                /div> <
                div className = "cir-card-bottom" > < /div> <
                /div>
            ))
        } <
        /div>

        <
        br / >
        <
        br / >

        <
        div className = "div-fam" >
        <
        div className = "sid-fam" > { /* Bride Relations */ } {
            [0, 1, 2, 3].map((index) => ( <
                div key = { index }
                className = "grp-rel" >
                <
                div className = "cir-div-card" >
                <
                div className = "cir-card-top" >
                <
                img src = { pranayImage }
                alt = "" / >
                <
                /div> <
                div className = "cir-card-bottom" > < /div> <
                /div> <
                div className = "fam-text" >
                <
                p className = "text5 tecen cred" > Name < /p> <
                p className = "text4 tecen" > Bride Relation < /p> <
                /div> <
                /div>
            ))
        } <
        /div> <
        div className = "sid-fam" > { /* Groom Relations */ } {
            [0, 1, 2, 3].map((index) => ( <
                div key = { index }
                className = "grp-rel" >
                <
                div className = "cir-div-card" >
                <
                div className = "cir-card-top" >
                <
                img src = { pranayImage }
                alt = "" / >
                <
                /div> <
                div className = "cir-card-bottom" > < /div> <
                /div> <
                div className = "fam-text" >
                <
                p className = "text5 tecen cred" > Name < /p> <
                p className = "text4 tecen" > Groom Relation < /p> <
                /div> <
                /div>
            ))
        } <
        /div> <
        /div> <
        /div>

        { /* Gallery Section */ } <
        div className = "page-gallery" >
        <
        div className = "div-title" >
        <
        div className = "title-top-icon" >
        <
        img src = { loveBirdImage }
        alt = "" / >
        <
        /div> <
        div className = "title-text-div" >
        <
        p className = "font-title cblack" > Gallery < /p> <
        /div> <
        div className = "title-bottom-icon" >
        <
        img src = { loveDualImage }
        alt = "" / >
        <
        /div> <
        /div> <
        div className = "box-card" > { /* Gallery cards */ } {
            [0, 1, 2, 3, 4].map((index) => ( <
                div key = { index }
                className = "div-card" >
                <
                div className = "card-top" >
                <
                img src = { pranayImage }
                alt = "" / >
                <
                /div> <
                div className = "card-bottom" > < /div> <
                /div>
            ))
        } <
        /div> <
        /div> <
        /div>
    );
};

export default FamilyComponent;