import React, { useEffect, useState } from 'react';
import ganesh from './gan.png';

const Countdown = () => {
  const [countdown, setCountdown] = useState({
    years: 0,
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  }); 

  const [doneBool, setDoneBool] = useState(true);
  const whoinvite = 0;
  const calculateCountdown = () => {
    const weddingDate = new Date('2023-10-26T12:32:00');
    const now = new Date();
    const timeDifference = now-weddingDate;
    if (timeDifference > 0) {
      const oneSecond = 1000;
      const oneMinute = oneSecond * 60;
      const oneHour = oneMinute * 60;
      const oneDay = oneHour * 24;
      const oneYear = oneDay * 365;
      const years = Math.floor(timeDifference / oneYear);
      const days = Math.floor((timeDifference % oneYear) / oneDay);
      const hours = Math.floor((timeDifference % oneDay) / oneHour);
      const minutes = Math.floor((timeDifference % oneHour) / oneMinute);
      const seconds = Math.floor((timeDifference % oneMinute) / oneSecond);
      setCountdown({ years, days, hours, minutes, seconds });
    } else {
        const oneSecond = 1000;
        const oneMinute = oneSecond * 60;
        const oneHour = oneMinute * 60;
        const oneDay = oneHour * 24;
        const oneYear = oneDay * 365;
        const positivetimeDifference = timeDifference*-1;
        const years = Math.floor(positivetimeDifference / oneYear);
        const days = Math.floor((positivetimeDifference % oneYear) / oneDay);
        const hours = Math.floor((positivetimeDifference % oneDay) / oneHour);
        const minutes = Math.floor((positivetimeDifference % oneHour) / oneMinute);
        const seconds = Math.floor((positivetimeDifference % oneMinute) / oneSecond);
        setCountdown({ years, days, hours, minutes, seconds });
    }
  };

  useEffect(() => {
    const timer = setInterval(calculateCountdown, 1000);
    calculateCountdown(); // Calculate the countdown immediately on component mount
    return () => clearInterval(timer); // Clean up the interval on unmount
  }, []);

  return (
    <div className="page-countdown">
      <div className="bg-fil-bla">
        <p className="fam-nam">
        {doneBool ?(
            <span className="disAMar">We are a Family now!</span>
        ):( 
            (whoinvite === 1)? (
            <span className="disSMBM">Bride Family's wedding Invitation</span>
        ): (
            <span className="disSFBM">Groom Family's wedding Invitation</span>
        )
        )}
        </p>
        <div className="con-pat">
          <div className="left cwhite tecen">
             {!doneBool && (<p className="text5 disBMar">We invite you to the wedding of</p>)}
            
            <p className="BG-nam">Bride <img src={ganesh}  alt=""/>Groom</p>
            <br />
            <p className="text5"> 
            {doneBool? ( <span className="disAMar">got married on</span>):(<span className="disBMar">on</span>)}
              
            </p>
            <p className="text6">Thursday, 26<sup>th</sup> May, 2022 at 12:32 p.m</p>

            {/* <p className="text5">
              <span className="disBMar"><br /><br /><br /></span>
              <span className="disAMar">at<br /></span>
            </p> */}
            <p className="text4"><i className="fa-solid fa-location-dot"></i> &nbsp;&nbsp; L.B Convention, Beside S.R.R Function Hall, Nirmal Road, Bhainsa</p>
            <br />
            {!doneBool && (<div className="flex-row disBMar">
              <a href="wa.me/917680904589">
                <div className="but-map">
                  <div className="but-map-lay flex-row">
                    <div className="flex-row">
                      <div><img src="map.png" alt="" /></div>
                      <div>
                        <p className="tex">Google Maps</p>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
            </div>)} 

            
          </div>
          <div className="right">
            <p className="text5 cwhite tecen">
            {!doneBool ? (<span className="disBMar">We are left with</span>):(<span className="disAMar">They are happy since </span>)}
            </p>
            <div id="div-con-tim">
                <div className="div-com">
                  <div className="tim-val">
                    <p id="tim-year">{countdown.years}</p>
                  </div>
                  <div className="tim-val-nam">
                    <p id="tim-year-cat">{countdown.years === 1 ? 'Year' : 'Years'}</p>
                  </div>
                </div>
                <div className="div-com">
                  <div className="tim-val">
                    <p id="tim-day">{countdown.days}</p>
                  </div>
                  <div className="tim-val-nam">
                    <p id="tim-day-cat">{countdown.days === 1 ? 'Day' : 'Days'}</p>
                  </div>
                </div>
                <div className="div-com">
                  <div className="tim-val">
                    <p id="tim-hour">{countdown.hours}</p>
                  </div>
                  <div className="tim-val-nam">
                    <p id="tim-hour-cat">{countdown.hours === 1 ? 'Hour' : 'Hours'}</p>
                  </div>
                </div>
                <div className="div-com">
                  <div className="tim-val">
                    <p id="tim-min">{countdown.minutes}</p>
                  </div>
                  <div className="tim-val-nam">
                    <p id="tim-min-cat">{countdown.minutes === 1 ? 'Minute' : 'Minutes'}</p>
                  </div>
                </div>
                <div className="div-com">
                  <div className="tim-val">
                    <p id="tim-sec">{countdown.seconds}</p>
                  </div>
                  <div className="tim-val-nam">
                    <p id="tim-sec-cat">{countdown.seconds === 1 ? 'Second' : 'Seconds'}</p>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Countdown;

