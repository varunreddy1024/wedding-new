import React from 'react';

const Event = () => {
    const maintime = 1;

    return (
        maintime === 0 ? ( <
            div className = "page-event Event" >
            <
            div className = "div-title" >
            <
            div className = "title-top-icon" > < img src = "love-bird.png"
            alt = "" / > < /div> <
            div className = "title-text-div" >
            <
            p className = "font-title cblack" > Wedding Events < /p> <
            /div> <
            div className = "title-bottom-icon" > < img src = "love-dual.png"
            alt = "" / > < /div> <
            /div> <
            div className = "event-main" >
            <
            div className = "event-sub" / >
            <
            div className = "event-det" >
            <
            p className = "text6 cred" > The reception < /p> <
            p className = "text4" > < i className = "fa-solid fa-location-dot" > < /i> &nbsp;&nbsp; Our Residence</p >
            <
            p className = "text4" > < i className = "fa-solid fa-clock" > < /i> &nbsp;&nbsp; May 27, 2022 at 5:00 pm</p >
            <
            p className = "event-cont" > Lorem, ipsum dolor sit amet consectetur adipisicing elit. < /p> <
            /div> <
            /div> <
            /div>
        ) : null
    );
};

export default Event;