import React from 'react';
import loveFillImage from './love-fill.png';
import loveDualImage from './love-dual.png';

function Page1() {
    return ( <
        div className = "page-1" >
        <
        div className = "bg-fil-bla" >
        <
        div className = "div-hom" >
        <
        div className = "hom-tit" >
        <
        div className = "div-tit-bro" >
        <
        p className = "bro-tit" > Bride < /p> <
        /div> <
        div className = "div-tit-symbol" >
        <
        img src = { loveFillImage }
        alt = ""
        className = "love" / >
        <
        /div> <
        div className = "div-tit-gro" >
        <
        p className = "gro-tit" > Groom < /p> <
        /div> <
        /div> <
        p className = "hom-get-text tecen" >
        <
        span className = "disBMar" > are getting married < /span> <
        span className = "disAMar" > Have got married < /span> <
        /p> <
        div className = "hom-div-title" >
        <
        div className = "hom-title-text-div" >
        <
        p className = "hom-font-title tecen" > 26 < sup > th < /sup> May, 2022 12:32 p.m</p >
        <
        /div> <
        div className = "hom-title-bottom-icon" >
        <
        img src = { loveDualImage }
        alt = "" / >
        <
        /div> <
        /div> <
        div className = "button disBMar"
        onClick = {
            () => alert('save the date') } >
        <
        div className = "layer" > < /div> <
        div className = "tex flex-col" >
        <
        h4 > Save the Date < /h4> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div>
    );
}

export default Page1;